
const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const ask = (q) => new Promise(resolve => rl.question(q, resolve));
const url = "http://localhost:5000/api/products";

async function start() {
    console.log("\nINVENTORY MANAGEMENT SYSTEM");
    console.log("Commands: all, add name, low, id ID, category name, delete name, exit\n");

    while (true) {
        const command = (await ask("> ")).trim();

        if (command.toLowerCase() === "exit") break;

        try {
            if (command.toLowerCase() === "all") {
                const res = await fetch(`${url}?limit=1000`);
                const data = await res.json();
               console.table(Object.fromEntries(
    data.products.map((p, i) => [
        i + 1,
        {
            ID: p._id,
            Name: p.name,
            Quantity: p.quantity,
            Price: p.price,
            Category: p.category
        }
    ])
));
                console.log("Total products:", data.totalProducts);

            } else if (command.toLowerCase() === "low") {
                const res = await fetch(`${url}/low-stock`);
                const data = await res.json();
                console.table(data.products);
                console.log("Low stock products:", data.totalLowStockProducts);

            } else if (command.toLowerCase().startsWith("id ")) {
                const id = command.slice(3).trim();
                const res = await fetch(`${url}/${id}`);
                console.log(await res.json());

            } else if (command.toLowerCase().startsWith("category ")) {
                const category = command.slice(9).trim();
                const res = await fetch(`${url}?category=${encodeURIComponent(category)}&limit=1000`);
                const data = await res.json();
                console.table(data.products);

            } else if (command.toLowerCase().startsWith("add ")) {
                const name = command.slice(4).trim();
                const quantity = Number(await ask("Quantity to add: "));
                const price = Number(await ask("Price: "));
                const category = await ask("Category: ");

                const res = await fetch(url, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ name, quantity, price, category })
                });

                console.log(await res.json());

            } else if (command.toLowerCase().startsWith("delete ")) {
                const name = command.slice(7).trim();
                const res = await fetch(`${url}/name/${encodeURIComponent(name)}`, {
                    method: "DELETE"
                });
                console.log(await res.json());

            } else {
                const res = await fetch(url);
                const data = await res.json();
                const products = data.products || [];
                const product = products.find(p =>
                    p.name.toLowerCase().includes(command.toLowerCase())
                );

                if (product) console.table([product]);
                else console.log("Product not found!");
            }

        } catch (error) {
            console.log("Error:", error.message);
        }
    }

    rl.close();
}

start();
