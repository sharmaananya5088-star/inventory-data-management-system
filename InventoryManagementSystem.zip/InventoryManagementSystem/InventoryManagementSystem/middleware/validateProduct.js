
const validateProduct = (req, res, next) => {
    const { name, quantity, price, category } = req.body;

    if (!name || !category) {
        return res.status(400).json({
            message: "Name and category are required"
        });
    }

    if (typeof quantity !== "number" || quantity < 0) {
        return res.status(400).json({
            message: "Quantity must be a valid non-negative number"
        });
    }

    if (typeof price !== "number" || price < 0) {
        return res.status(400).json({
            message: "Price must be a valid non-negative number"
        });
    }

    next();
};

module.exports = validateProduct;
