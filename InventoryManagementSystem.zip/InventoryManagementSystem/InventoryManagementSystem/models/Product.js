
const mongoose = require("mongoose");

const productSchema = new mongoose.Schema({
       productId: {
    type: Number
},
    name: {
        type: String,
        required: true
    },
    quantity: {
        type: Number,
        required: true
    },
    price: {
        type: Number,
        required: true
    },
    category: {
        type: String,
        required: true
    }
});

module.exports = mongoose.model("Product", productSchema);

