
const express = require("express");
const router = express.Router();
const Product = require("../models/Product");
const validateProduct = require("../middleware/validateProduct");// ADD NEW PRODUCT
router.post("/", validateProduct, async (req, res) => {
    try {
        const { name, quantity, price, category } = req.body;

        const matchingProducts = await Product.find({
            name: name.trim()
        }).collation({ locale: "en", strength: 2 });

        if (matchingProducts.length > 0) {
            const product = matchingProducts[0];

            product.quantity =
                matchingProducts.reduce((sum, p) => sum + p.quantity, 0)
                + quantity;

            await product.save();

            if (matchingProducts.length > 1) {
                await Product.deleteMany({
                    _id: {
                        $in: matchingProducts.slice(1).map(p => p._id)
                    }
                });
            }

            return res.json({
                message: "Stock added successfully",
                product
            });
        }

        const lastProduct = await Product.findOne().sort({ productId: -1 });

const nextId = lastProduct ? lastProduct.productId + 1 : 1;

const product = await Product.create({
    productId: nextId,
    name: name.trim(),
    quantity,
    price,
    category
});

        res.status(201).json(product);

    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});
    
// GET ALL PRODUCTS WITH FILTERING, SORTING AND PAGINATION
router.get("/", async (req, res) => {
    try {
        const {
            category,
            sortBy = "name",
            order = "asc",
            page = 1,
            limit = 10
        } = req.query;

        const filter = {};

        if (category) {
            filter.category = category;
        }

        const allowedSortFields = ["name", "price", "quantity"];

        if (!allowedSortFields.includes(sortBy)) {
            return res.status(400).json({
                message: "Invalid sorting field"
            });
        }

        const sortOrder = order === "desc" ? -1 : 1;
        const sort = { [sortBy]: sortOrder };

        const currentPage = Math.max(1, parseInt(page) || 1);
        const pageLimit = Math.max(1, parseInt(limit) || 10);

        const totalProducts = await Product.countDocuments(filter);

        const products = await Product.find(filter)
            .sort(sort)
            .skip((currentPage - 1) * pageLimit)
            .limit(pageLimit);

        res.json({
            currentPage,
            totalProducts,
            totalPages: Math.ceil(totalProducts / pageLimit),
            products
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});


// LOW STOCK ALERT REPORT
router.get("/low-stock", async (req, res) => {
    try {
        const products = await Product.find({
            quantity: { $lt: 10 }
        });

        res.json({
            totalLowStockProducts: products.length,
            products
        });
    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});

// CATEGORY-WISE INVENTORY SUMMARY
router.get("/summary", async (req, res) => {
    try {
        const summary = await Product.aggregate([
            {
                $group: {
                    _id: "$category",
                    totalProducts: { $sum: 1 },
                    totalQuantity: { $sum: "$quantity" },
                    totalValue: {
                        $sum: {
                            $multiply: ["$quantity", "$price"]
                        }
                    }
                }
            }
        ]);

        res.json(summary);

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});

// GET PRODUCT BY ID
router.get("/:id", async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);

        if (!product) {
            return res.status(404).json({
                message: "Product not found"
            });
        }

        res.json(product);
    } catch (error) {
        res.status(400).json({
            message: error.message
        });
    }
});

// UPDATE PRODUCT
router.put("/:id", validateProduct, async (req, res) => {
    try {
        const product = await Product.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true }
        );

        if (!product) {
            return res.status(404).json({
                message: "Product not found"
            });
        }

        res.json(product);
    } catch (error) {
        res.status(400).json({
            message: error.message
        });
    }
});

// STOCK ADJUSTMENT
router.patch("/:id/stock", async (req, res) => {
    try {
        const { change } = req.body;

        if (typeof change !== "number" || change === 0) {
            return res.status(400).json({
                message: "Please provide a valid stock change"
            });
        }

        const product = await Product.findById(req.params.id);

        if (!product) {
            return res.status(404).json({
                message: "Product not found"
            });
        }

        if (product.quantity + change < 0) {
            return res.status(400).json({
                message: "Insufficient stock"
            });
        }

        product.quantity += change;
        await product.save();

        res.json({
            message: "Stock updated successfully",
            product
        });

    } catch (error) {
        res.status(400).json({
            message: error.message
        });
    }
});

// DELETE PRODUCT
router.delete("/:id", async (req, res) => {
    try {
        const product = await Product.findByIdAndDelete(req.params.id);

        if (!product) {
            return res.status(404).json({
                message: "Product not found"
            });
        }

        res.json({
            message: "Product deleted successfully"
        });
    } catch (error) {
        res.status(400).json({
            message: error.message
        });
    }
});
router.delete("/name/:name", async (req, res) => {
    const product = await Product.findOneAndDelete({
        name: req.params.name
    });

    if (!product) {
        return res.status(404).json({ message: "Product not found" });
    }

    res.json({ message: "Product deleted successfully" });
});
module.exports = router;
