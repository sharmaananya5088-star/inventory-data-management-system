
const express = require("express");
const mongoose = require("mongoose");
require("dotenv").config();

const app = express();

// Middleware
app.use(express.json());

// Product routes
app.use("/api/products", require("./routes/productRoutes"));

// Home route
app.get("/", (req, res) => {
    res.send("Inventory Management System is Running!");
});

// Database connection
const startServer = async () => {
    try {
        if (!process.env.MONGO_URI) {
            throw new Error("MONGO_URI is missing in .env file");
        }

        await mongoose.connect(process.env.MONGO_URI);

        console.log("MongoDB Connected Successfully!");

        const PORT = process.env.PORT || 5000;

        app.listen(PORT, () => {
            console.log(`Server running on port ${PORT}`);
        });

    } catch (error) {
        console.error("Database Connection Failed!");
        console.error(error.message);
    }
};

startServer();
